<template xmlns:v-slot="http://www.w3.org/1999/XSL/Transform">
    <div class="container">
        <div id="Cart">
            <h2 class="title">سبد خريد</h2>
            <h3 class="head" v-text="'محتويات سبد خريد شما:  '+Carts.length +' محصول'"></h3>
            <b-table :items="Carts" :fields="CartFields" class="table" style="direction: rtl">
                <template v-slot:cell(CartID)="data">
                    {{ data.index + 1 }}
                </template>
                <template v-slot:cell(ContentName)="data">
                    {{ data.item.Content.ContentName}}
                </template>
                <template v-slot:cell(ProductPrice)="data">
                    <span v-if="data.item.Content.Products[0]"> {{ data.item.Content.Products[0].ProductPrice}}</span>

                </template>
                <template v-slot:cell(Quntity)="data">
                    {{ data.item.Quantity}}
                </template>
                <template v-slot:cell(Total)="data">
                    <span v-if="data.item.Content.Products[0]"> {{ data.item.Content.Products[0].ProductPrice * data.item.Quantity }}</span>
                </template>
            </b-table>
            <div class="info">
                <table>
                    <tr>
                        <td class="label">جمع محصولات:</td>
                        <td>{{Tot}}</td>
                    </tr>
                    <tr>
                        <td class="label">هزینه بسته بندی و ارسال:</td>
                        <td>{{post}}</td>
                    </tr>
                    <tr>
                        <td class="label">مجموع:</td>
                        <td>{{Total}}</td>
                    </tr>
                    <tr>
                        <td class="label"></td>
                        <td><button class="btn btn-primary c-btn" @click="SendPay()"><font-awesome-icon  icon="money-bill-alt" /><span>پرداخت</span></button></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Cart",
        props: {
            UrlGetCart: {
                type: String,
                required: true,
            },
            UrlSendPay: {
                type: String,
                required: true,
            },
        },
        data(){
            return{
                Carts:[],
                CartFields:[
                    { key: 'CartID', label: 'ردیف' },
                    { key: 'ContentName', label: 'نام کالا' },
                    { key: 'ProductPrice', label: 'قیمت(تومان)' },
                    { key: 'Quntity', label: 'تعداد' },
                    { key: 'Total', label: 'جمع(تومان)' },
                ],
                Tot:null,
                Total:null,
                post:12500
            }
        },
        mounted() {
            this.GetCart();
        },
        methods:{
            GetCart(){
                axios
                    .get(this.UrlGetCart)
                    .then(response => {
                        var data=response.data;
                        console.log(data) ;
                        this.Carts=data;
                        this.total(data);
                    })
            },
            SendPay(){
                axios
                    .post(this.UrlSendPay,{
                        PayPrice:100,
                        PayDesc:'خرید',
                        PayEmail:"moosarahimi8@gmail.com",
                        PayPhone:'09107608438',
                        PayOrder:4,

                    })
                    .then(response => {
                        var data=response.data;
                        console.log(data) ;
                        window.location.replace(data);
                    })
            },
            total(data){/*data.length*/
                var tot=0;
                for(var i=0;i<2;i++){
                    tot += (data[i].Quantity *   data[i].Content.Products[0].ProductPrice);
                    console.log(data[i].Content.Products[0].ProductPrice) ;
                    console.log(data[i].Quantity *   data[i].Content.Products[0].ProductPrice) ;
                }
                console.log(tot) ;
                this.Tot=tot;
                this.Total=tot+this.post;
            }

        }
    }
</script>

<style scoped>

</style>
