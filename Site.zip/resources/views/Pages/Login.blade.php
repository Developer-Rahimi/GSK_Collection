@extends('layouts.app')

@section('content')
    <div class="container">
        <Login
            Url-Login="{{route('User.Login')}}"
            Url-Check-Email="{{route('User.CheckEmail')}}"
        ></Login>
    </div>

@endsection

