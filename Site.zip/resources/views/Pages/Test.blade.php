@extends('layouts.app')

@section('content')
    <div class="container">
        <Test> </Test>
    </div>

@endsection
