@extends('layouts.app')

@section('content')
    <div class="container">
       <About></About>
    </div>
@endsection
