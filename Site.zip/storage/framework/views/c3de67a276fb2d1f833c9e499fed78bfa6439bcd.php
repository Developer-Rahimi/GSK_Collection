<?php $__env->startSection('content'); ?>
    <div class="container">
        <Show-Content
            Url-Get-Content="<?php echo e(route('Get.Content')); ?>"
            Url-Send-Comment="<?php echo e(route('Send.Comment')); ?>"
            Index="<?php echo e($id); ?>"
        ></Show-Content>
        <?php echo e($id); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer\Desktop\Site\resources\views/Pages/ShowContent.blade.php ENDPATH**/ ?>