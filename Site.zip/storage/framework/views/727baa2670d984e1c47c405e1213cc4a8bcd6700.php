<?php $__env->startSection('content'); ?>
    <div class="container">
       <Contact
               Url-Get-Contact="<?php echo e(route('Get.Contact')); ?>"
               Url-Send-Contact="<?php echo e(route('Send.Contact')); ?>"
       ></Contact>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer\Desktop\Site\resources\views/Pages/Contact.blade.php ENDPATH**/ ?>