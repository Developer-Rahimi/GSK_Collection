<?php $__env->startSection('content'); ?>

    <Account
        Url-Get-User="<?php echo e(route('Get.Users')); ?>"
        Index="<?php echo e($Index); ?>"
    ></Account>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer\Desktop\Site\resources\views/Pages/Account.blade.php ENDPATH**/ ?>